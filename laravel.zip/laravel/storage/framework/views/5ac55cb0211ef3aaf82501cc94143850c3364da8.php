<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">        
        <div class="row my-4">
          <!-- Small table -->
          
          <div class="col-md-12">
            <div class="row align-items-center mb-4">
                <div class="col">
                  <h2 class="page-title">Instruct Cover</h2>
                </div>
                
            </div>
            <div class="card shadow">
              <div class="card-body">
                <!-- table -->
                <table class="table datatables" id="dataTable-1">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Tanggal</th>
                      
                      <th>Insured</th>
                      <th>Insurance</th>
                      <th>Aksi</th>
                      
                      
                    </tr>
                  </thead>
                  <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $instructs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instruct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($instruct->id); ?> </td>
                        <td><?php echo e($instruct->date); ?></td>
                        <td><?php echo e($instruct->insureds->name); ?>  </td>
                        <td><?php echo e($instruct->insurance->name); ?>  </td>

                        
                        
                        
                        
                        <td>
                          <div class="dropdwn">
                            <button style="background-color: #3294fe !important; color: #ffffff;"  class="btn btn-sm dropdown-toggle" type="button" id="dr1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                              <span class="text-muted sr-only">Action</span>
                              Tindakan
                            </button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dr1">
                              <?php if($instruct->status == 'UNAPPROVED'): ?>
                              
                                <a href="<?php echo e(route('placing.status', $instruct->id)); ?>?status=APPROVED" class="dropdown-item">                                                     <i class="fe fe-check"></i>
                                    APPROVE
                                </a>
                                <a href="<?php echo e(route('placing.status', $instruct->id)); ?>?status=REJECTED" class="dropdown-item">                                                     <i class="fe fe-x"></i>
                                    REJECT
                                </a>
                                

                              <?php endif; ?>
                              
                              <a class="dropdown-item " href="<?php echo e(route('instruct.show', $instruct->id)); ?> "><i class="fe fe-file-text"></i>Cetak</a>
                              
                            </div>
                          </div>  
                        </td>
                        
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td colspan="9" class="text-center p-4">
                            Data tidak tersedia
                        </td>
                      </tr>
                      <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div> <!-- simple table -->
        </div> <!-- end section -->
      </div> <!-- .col-12 -->
    </div> <!-- .row -->
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script src='<?php echo e(asset('js/jquery.dataTables.min.js')); ?>'></script>
<script src='<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>'></script>
<script>
  $('#dataTable-1').DataTable(
  {
    autoWidth: true,
    "lengthMenu": [
      [16, 32, 64, -1],
      [16, 32, 64, "All"]
    ]
  });
</script> --}}
{{-- <script src="js/apps.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/pialang/resources/views/pages/instruct/index.blade.php ENDPATH**/ ?>