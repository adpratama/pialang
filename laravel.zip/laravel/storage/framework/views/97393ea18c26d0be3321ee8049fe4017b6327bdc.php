<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/simplebar.min.js')); ?>"></script>
    <script src='<?php echo e(asset('js/daterangepicker.js')); ?>'></script>
    <script src='<?php echo e(asset('js/jquery.stickOnScroll.js')); ?>'></script>
    <script src="<?php echo e(asset('js/tinycolor-min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/config.js')); ?>"></script>
    <script src="<?php echo e(asset('js/d3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/topojson.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datamaps.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datamaps-zoomto.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datamaps.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
    <script>
      /* defind global options */
      Chart.defaults.global.defaultFontFamily = base.defaultFontFamily;
      Chart.defaults.global.defaultFontColor = colors.mutedColor;
    </script>
    
    <script src='<?php echo e(asset('js/jquery.timepicker.js')); ?>'></script>
    <script src='<?php echo e(asset('js/dropzone.min.js')); ?>'></script>
    <script src='<?php echo e(asset('js/uppy.min.js')); ?>'></script>
    <script src='<?php echo e(asset('js/quill.min.js')); ?>'></script>
    <script src="<?php echo e(asset('assets/air-datepicker/dist/js/datepicker.js')); ?> "></script>
    <script src="<?php echo e(asset('assets/air-datepicker/dist/js/i18n/datepicker.en.js')); ?> "></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/22.0.0/classic/ckeditor.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src='<?php echo e(asset('js/select2.min.js')); ?>'></script>


    
    
    <?php /**PATH /var/www/html/pialang/resources/views/includes/script.blade.php ENDPATH**/ ?>