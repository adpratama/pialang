
  

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
   <?php echo csrf_field(); ?>
</form>
  <?php /**PATH /var/www/html/pialang/resources/views/includes/navbar.blade.php ENDPATH**/ ?>